
# BARD
## Technology Used
* React With Veet
* React Tostify
* Tailwind CSS
* DaisyUI
* ReCharts


